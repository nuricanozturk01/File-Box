#!/bin/bash

app_path = "D:\Staj\File-Box\FileBoxApp.exe"
port="5299"

echo "Starting File Box App on port $port..."
nohup "$app_path" --urls "http://localhost:$port" > /dev/null 2>&1 &
