package com.example.yediiklim.Controller;

import com.example.yediiklim.Entity.CostType;
import com.example.yediiklim.HibernateConfiguration.SessionFactoryManager;
import com.example.yediiklim.util.StringControl;
import com.example.yediiklim.util.UtilFX;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;

public class CostTypeController
{
    @FXML
    private TextField costTypeTextField;
    private MainScreenController mainScreenController;

    @FXML
    private void pressKey(KeyEvent keyEvent)
    {
        if (keyEvent.getCode() == KeyCode.ENTER)
            clickSaveButton();
    }

    // Dependency Injection
    public void setMainScreenController(MainScreenController mainScreenController) {
        this.mainScreenController = mainScreenController;
    }

    private void addToDatabase(CostType costType)
    {
        SessionFactoryManager.add(costType);
        mainScreenController.getService().addCostTypeTable(costType);
    }
    @FXML
    private void clickSaveButton()
    {
        try
        {
            if (!StringControl.isValid(costTypeTextField.getText()))
                throw new Exception();

            var costTypeString = costTypeTextField.getText();
            var costType = new CostType(costTypeString);

            addToDatabase(costType);

            clear();

            UtilFX.alertScreen(Alert.AlertType.INFORMATION,"Gider türü başarıyla eklendi!", ButtonType.OK);
        }
        catch (Exception ignore)
        {
            UtilFX.alertScreen(Alert.AlertType.ERROR,"Lütfen boş bırakmayınız!", ButtonType.OK);
        }
    }

    private void clear()
    {
        costTypeTextField.clear();
    }
}
