package com.example.yediiklim.Controller;

import com.example.yediiklim.Entity.CostFlow;
import com.example.yediiklim.HibernateConfiguration.SessionFactoryManager;
import javafx.fxml.FXML;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ListCell;
import javafx.scene.control.TextField;
import java.math.BigDecimal;
import java.util.List;

/**
 * TODO: DB
 */
public class SumOfCostType
{
    @FXML
    private TextField sumOfTextField;
    @FXML
    private ChoiceBox<String> choiceBox;
    private List<CostFlow> costFlows;
    @FXML
    private void initialize()
    {
        costFlows = SessionFactoryManager.getCostFlowList();
        SessionFactoryManager.getCostTypes().forEach(e -> choiceBox.getItems().add(e.getCostType()));
    }
    private ListCell<String> getListCell()
    {
        return new ListCell<>() {
            @Override
            public void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                setText(item);
            }
        };
    }
    private BigDecimal getSum(List<CostFlow> types)
    {
        return types.stream().map(CostFlow::getCost).reduce(BigDecimal.ZERO, BigDecimal::add);
    }
    @FXML
    private void getResult()
    {
        var list = costFlows.stream()
                .filter(e -> e.getExpenseType().equals(choiceBox.getSelectionModel().getSelectedItem()))
                .toList();
        var sum = getSum(list);

        sumOfTextField.setText(sum.toString() + " ₺");
    }
}
