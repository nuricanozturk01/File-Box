package com.example.yediiklim.Controller;

import com.example.yediiklim.Entity.CostForm;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class CostFormTableController
{
    @FXML
    private  AnchorPane rootPane;
    private List<CostForm> list;
    @FXML
    private TableView<CostForm> costFormTable;
    @FXML
    private TableColumn<CostForm, LocalDate> dateColumnColumn;
    @FXML
    private TableColumn<CostForm, Integer> billingNoColumn;
    @FXML
    private TableColumn<CostForm, String> descriptionColumn;
    @FXML
    private TableColumn<CostForm, String> costTypeColumn;
    @FXML
    private TableColumn<CostForm, BigDecimal> invoiceAmountColumn;
    @FXML
    private TableColumn<CostForm, Double> kdvColumn;
    @FXML
    private TableColumn<CostForm, BigDecimal> totalInvoiceColumn;
    @FXML
    private TableColumn<CostForm, String> officerColumn;
    @FXML
    private TableColumn<CostForm, String> companyColumn;

    @FXML
    private void initialize()
    {
        // set of CellValueFactory
        dateColumnColumn.setCellValueFactory(new PropertyValueFactory<>("Date"));
        billingNoColumn.setCellValueFactory(new PropertyValueFactory<>("BillingNumber"));
        descriptionColumn.setCellValueFactory(new PropertyValueFactory<>("Description"));
        costTypeColumn.setCellValueFactory(new PropertyValueFactory<>("CostType"));
        invoiceAmountColumn.setCellValueFactory(new PropertyValueFactory<>("InvoiceAmount"));
        totalInvoiceColumn.setCellValueFactory(new PropertyValueFactory<>("TotalInvoice"));
        kdvColumn.setCellValueFactory(new PropertyValueFactory<>("Kdv"));
        officerColumn.setCellValueFactory(new PropertyValueFactory<>("ExpenditureOfficer"));
        companyColumn.setCellValueFactory(new PropertyValueFactory<>("Company"));

        // Title of listview formatted date
        dateColumnColumn.setCellFactory((column) -> getFormattedDate());
    }

    public void setList(List<CostForm> list)
    {
        this.list = list;
        fillTable();
    }

    // Print dd/mm/yyyy format to Table
    private TableCell<CostForm, LocalDate> getFormattedDate()
    {
        return new TableCell<>()
        {
            @Override
            protected void updateItem(LocalDate item, boolean empty)
            {
                super.updateItem(item, empty);
                setText(empty ? null : DateTimeFormatter.ofPattern("dd/MM/yyyy").format(item));
            }
        };
    }
    private BigDecimal getSumOfCost()
    {
        return list.stream().map(CostForm::getTotalInvoice).reduce(BigDecimal.ZERO, BigDecimal::add);
    }
    private void fillTable()
    {
        var sumOfCost = getSumOfCost();

        var stage = (Stage) rootPane.getScene().getWindow();

        stage.setTitle(stage.getTitle() + "     Toplam: " + sumOfCost.toString() + " ₺");

        costFormTable.setItems(FXCollections.observableList(list));
    }
}
