package com.example.yediiklim.Controller;

import com.example.yediiklim.Entity.User;
import com.example.yediiklim.HibernateConfiguration.SessionFactoryManager;
import javafx.fxml.FXML;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import java.util.List;

public class SumOfPersonWithYear
{
    public Label sumOfTotalLabel;
    public ChoiceBox<String> choiceBox;
    public TextField costTypeTextField;
    public ChoiceBox<Integer> yearChoiceBox;
    private List<User> users;

    private User user;
    @FXML
    private void initialize()
    {
        users = SessionFactoryManager.getUserList();
        users.stream().map(user ->user.getName() + " " + user.getSurname()).forEach(choiceBox.getItems()::add);
    }

    private boolean isValid(User p)
    {
        var fullName = p.getName() + " " + p.getSurname();

        return fullName.equals(choiceBox.getSelectionModel().getSelectedItem());
    }

    @SuppressWarnings("all")
    @FXML
    private void clickUserButton()
    {
        user = users.stream().filter(this::isValid).findFirst().orElse(null);

        var years = SessionFactoryManager.getDistinctYears(user.getUser_pk_id());

        yearChoiceBox.getItems().clear();

        years.forEach(yearChoiceBox.getItems()::add);

    }
    @FXML
    private void clickGetButton()
    {
        var year = yearChoiceBox.getSelectionModel().getSelectedItem();

        var sum = SessionFactoryManager.getSumOfCostForm(year, user.getUser_pk_id());

        costTypeTextField.setText((sum == null ? "0" : sum ) +  " ₺");
    }
}
