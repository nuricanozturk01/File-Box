package com.example.yediiklim.Controller;

import com.example.yediiklim.App;
import com.example.yediiklim.Entity.*;
import com.example.yediiklim.HibernateConfiguration.SessionFactoryManager;
import com.example.yediiklim.Service.MainScreenService;
import com.example.yediiklim.util.Constant;
import com.example.yediiklim.util.UtilFX;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;

public class MainScreenController
{
    @FXML
    private TableColumn<BankFlow, Integer> idColumnBankFlow;
    @FXML
    private Tab costFormTab;
    @FXML
    private Tab bankFlowTab;
    @FXML
    private Tab userTab;
    @FXML
    private Tab costTypeTab;
    @FXML
    private TabPane tabPane;
    @FXML
    private Button filterButtonDate;
    @FXML
    private Button filterButtonCostType;
    @FXML
    private Button searchNameButton;
    @FXML
    private TextField nameTextField;
    @FXML
    private TableColumn<CostType, String> costTypeColumnCostTypeTable;
    @FXML
    private DatePicker startDatePicker;
    @FXML
    private DatePicker finishDatePicker;
    @FXML
    private ChoiceBox<String> costTypeChoiceBox;
    @FXML
    private TableColumn<CostFlow, LocalDate> dateColumn;
    @FXML
    private TableColumn<CostFlow,String> caseFlowColumn;
    @FXML
    private TableColumn<CostFlow,String> costTypeColumn;
    @FXML
    private TableColumn<CostFlow,BigDecimal> costColumn;
    @FXML
    private TableColumn<BankFlow, LocalDate> dateColumnBank;
    @FXML
    private TableColumn<BankFlow,String> caseFlowColumnBank;
    @FXML
    private TableColumn<BankFlow,String> costTypeColumnBank;
    @FXML
    private TableColumn<BankFlow,BigDecimal> costColumnBank;
    @FXML
    private TableColumn<User,String> nameColumn;
    @FXML
    private TableColumn<User,String> surnameColumn;
    @FXML
    private TableView<CostFlow> costFlowTable;
    @FXML
    private TableView<BankFlow> bankFlowTable;
    @FXML
    private TableView<User> UsersTable;
    @FXML
    private TableView<CostType> costTypeTable;
    @FXML
    private TableColumn<CostFlow,Integer> noColumn;
    private MainScreenService service;

    @FXML
    private void initialize()
    {
        service = new MainScreenService.ServiceBuilder()
                .setBankFlowTable(bankFlowTable).setCaseFlowColumn(caseFlowColumn)
                .setCaseFlowColumnBank(caseFlowColumnBank).setCostColumn(costColumn).setCostColumnBank(costColumnBank)
                .setCostFlowTable(costFlowTable).setCostTypeChoiceBox(costTypeChoiceBox)
                .setCostTypeColumn(costTypeColumn).setCostTypeColumnBank(costTypeColumnBank)
                .setFinishDatePicker(finishDatePicker).setDateColumn(dateColumn)
                .setIdColumnBankFlow(idColumnBankFlow).setTabPane(tabPane)
                .setFilterButtonDate(filterButtonDate).setFilterButtonCostType(filterButtonCostType)
                .setSearchNameButton(searchNameButton).setNameTextField(nameTextField)
                .setCostTypeColumnCostTypeTable(costTypeColumnCostTypeTable).setStartDatePicker(startDatePicker)
                .setDateColumnBank(dateColumnBank).setNameColumn(nameColumn)
                .setSurnameColumn(surnameColumn).setUsersTable(UsersTable)
                .setCostTypeTable(costTypeTable).setNoColumn(noColumn)
                .build();

        service.init();
    }

    public MainScreenService getService()
    {
        return service;
    }

    /**
     * FILTER
     */
    @FXML
    private void filterSearchName()
    {
        var name = nameTextField.getText();

        if (costFormTab.isSelected())
            costFlowTable.setItems(FXCollections.observableList(SessionFactoryManager.filterNameCostFlows(name)));

        if (userTab.isSelected())
            UsersTable.setItems(FXCollections.observableList(SessionFactoryManager.filterNameUser(name)));

        if (costTypeTab.isSelected())
            costTypeTable.setItems(FXCollections.observableList(SessionFactoryManager.filterNameCostType(name)));

        if (bankFlowTab.isSelected())
            bankFlowTable.setItems(FXCollections.observableList(SessionFactoryManager.filterNameBankFlows(name)));
    }
    @FXML
    private void filterByDate()
    {
        if (costFormTab.isSelected())
            costFlowTable.setItems(FXCollections.observableList
                    (SessionFactoryManager.filterDateCostFlows(startDatePicker.getValue(), finishDatePicker.getValue())));

        if (bankFlowTab.isSelected())
            bankFlowTable.setItems(FXCollections.observableList
                    (SessionFactoryManager.filterDateBankFlows(startDatePicker.getValue(), finishDatePicker.getValue())));
    }
    @FXML
    private void clickFilterCostType()
    {
        var filterType = costTypeChoiceBox.getSelectionModel().getSelectedItem();

        if (costFormTab.isSelected())
            costFlowTable.setItems(FXCollections.
                    observableList(SessionFactoryManager.filterCostTypeCostFlows(filterType)));

        if (bankFlowTab.isSelected())
            bankFlowTable.setItems(FXCollections.
                    observableList(SessionFactoryManager.filterCostTypeBankFlows(filterType)));
    }
    @FXML
    private void resetTableButton()
    {
        service.initCostFlowTable();
        service.initUsersTable();
        service.initCostTypeTable();
        service.initBankFlowTable();
        startDatePicker.setValue(LocalDate.now());
        finishDatePicker.setValue(LocalDate.now());
        nameTextField.setText(null);
    }
    /**
     * Open Form methods
     * @throws IOException
     */
    @FXML
    private void clickCostForms() throws IOException
    {
        var loader = new FXMLLoader(App.class.getResource("masraf_form_list.fxml"));
        UtilFX.initStage("Masraf Formu Kişi Listesi", new Stage(), new Scene(loader.load()),false, Constant.ICON);
    }
    @FXML
    private void clickAddCostType() throws IOException
    {
        var loader = new FXMLLoader(App.class.getResource("gider_türü_ekleme_formu.fxml"));
        UtilFX.initStage("Gider Türü Ekleme Formu", new Stage(), new Scene(loader.load()),false, Constant.ICON);
        CostTypeController controller = loader.getController();
        controller.setMainScreenController(this);
    }
    @FXML
    @SuppressWarnings("all")
    private void clickAddKDV() throws IOException
    {
        Parent root  = FXMLLoader.load(App.class.getResource("kdv_ekleme_formu.fxml"));
        UtilFX.initStage("KDV Ekleme Formu", new Stage(), new Scene(root),false, Constant.ICON);
    }
    @FXML
    @SuppressWarnings("all")
    private void clickAddBankForm() throws IOException
    {
        Parent root  = FXMLLoader.load(App.class.getResource("banka_hareket_form.fxml"));
        UtilFX.initStage("Banka Hareketleri", new Stage(), new Scene(root),false, Constant.ICON);
    }
    @FXML
    private void clickAddCostForm() throws IOException
    {
        var loader = new FXMLLoader(App.class.getResource("masraf_ekleme_form.fxml"));
        UtilFX.initStage("Masraf Ekleme Formu", new Stage(), new Scene(loader.load()), false, Constant.ICON);
        CostFormController controller = loader.getController();
        controller.setMainScreenController(this);

    }
    @FXML
    private void clickAddPerson() throws IOException
    {
        var loader = new FXMLLoader(App.class.getResource("kisi_ekle.fxml"));
        //Parent root  = FXMLLoader.load(App.class.getResource("kisi_ekle.fxml"));

        UtilFX.initStage("Kişi Ekle", new Stage(), new Scene(loader.load()), false, Constant.ICON);

        AddPersonController controller = loader.getController();

        controller.setMainScreenController(this);
    }
    @FXML
    private void clickSumOfTotalCost() throws IOException
    {
        var loader = new FXMLLoader(App.class.getResource("toplam_gider.fxml"));

        UtilFX.initStage("Toplam Gider", new Stage(), new Scene(loader.load()), false, Constant.ICON);
        System.gc();
    }
    @FXML
    private void clickSumOfPersonWithYear() throws IOException
    {
        var loader = new FXMLLoader(App.class.getResource("kisi_yıl_toplam.fxml"));

        UtilFX.initStage("Kişi - Yıl", new Stage(), new Scene(loader.load()), false, Constant.ICON);
        System.gc();
    }
    @FXML
    private void clickSumOfWithCostType() throws IOException
    {
        var loader = new FXMLLoader(App.class.getResource("toplam_miktar_gider_türü.fxml"));

        UtilFX.initStage("Gider Türü", new Stage(), new Scene(loader.load()), false, Constant.ICON);
        System.gc();
    }
    @FXML
    private void clickdeletePerson()
    {
       try {
           var user = service.getUsersTable().getSelectionModel().getSelectedItem();

           if (user == null)
               throw new Exception();

           SessionFactoryManager.delete(user);
           service.updateUserTable();
       }
       catch (Exception ignored) {
       }
    }
    /**
     * Update Operations
     */
    @FXML
    private void clickUpdatePerson(){
       try {
           if (UsersTable.getSelectionModel().getSelectedItem() == null)
               throw new Exception();

           var loader = new FXMLLoader(App.class.getResource("kişi_güncelleme_form.fxml"));
           UtilFX.initStage("Kişi Güncelleme Formu", new Stage(), new Scene(loader.load()), false, Constant.ICON);

           UpdatePersonController controller = loader.getController();
           controller.setMainScreenController(this);

       }
       catch (Exception ignore) {

       }
       finally {
           System.gc();
       }
    }
    @FXML
    private void clickUpdateCostFlow()
    {
        try {
            if (costFlowTable.getSelectionModel().getSelectedItem() == null)
                throw new Exception();

            var loader = new FXMLLoader(App.class.getResource("masraf_güncelleme_form.fxml"));
            UtilFX.initStage("Masraf Güncelleme Formu", new Stage(), new Scene(loader.load()),false, Constant.ICON);

            var flow = costFlowTable.getSelectionModel().getSelectedItem();

            UpdateCostFormController controller = loader.getController();
            controller.setMainScreenController(this);
            controller.setCostFlow(flow);
            controller.setCostForm(SessionFactoryManager.get(CostForm.class,flow.getCost_flow_pk_id()));
            System.gc();

        }
        catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }
}